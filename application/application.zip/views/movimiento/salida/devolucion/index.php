		<div class="container" ></div>
		<div class="container" style="position: absolute;">
			<h5>SALIDA-CLIENTE</h5>
			<hr>
			
			<a class="btn btn-primary" href="<?php echo base_url(); ?>salida/cliente/formulario" role="button">Crear documento</a>
			
		</div>
