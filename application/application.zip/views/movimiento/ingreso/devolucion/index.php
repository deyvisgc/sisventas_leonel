		<div class="container" ></div>
		<div class="container" style="position: absolute;">
			<h5>INGRESO-PROVEEDOR</h5>
			<hr>
			
			<a class="btn btn-primary" href="<?php echo base_url(); ?>ingreso/proveedor/formulario" role="button">Crear documento</a>
			
		</div>
